"use strict";
exports.id = 434;
exports.ids = [434];
exports.modules = {

/***/ 8473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2322);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7729);



const CustomApp = ({ Component , pageProps  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: "Welcome to web!"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: "app",
                children: Component.PageLayout ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component.PageLayout, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomApp);


/***/ }),

/***/ 4736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _document)
});

// EXTERNAL MODULE: ../../node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(2322);
// EXTERNAL MODULE: ../../node_modules/next/document.js
var next_document = __webpack_require__(331);
// EXTERNAL MODULE: ../../node_modules/@emotion/server/create-instance/dist/emotion-server-create-instance.esm.js
var emotion_server_create_instance_esm = __webpack_require__(3251);
// EXTERNAL MODULE: ../../node_modules/@emotion/cache/dist/emotion-cache.esm.js + 9 modules
var emotion_cache_esm = __webpack_require__(5035);
;// CONCATENATED MODULE: ./config/createEmotionCache.tsx

const isBrowser = typeof document !== "undefined";
// On the client side, Create a meta tag at the top of the <head> and set it as insertionPoint.
// This assures that MUI styles are loaded first.
// It allows developers to easily override MUI styles with other styling solutions, like CSS modules.
function createEmotionCache() {
    let insertionPoint;
    if (isBrowser) {
        const emotionInsertionPoint = document.querySelector('meta[name="emotion-insertion-point"]');
        insertionPoint = emotionInsertionPoint !== null && emotionInsertionPoint !== void 0 ? emotionInsertionPoint : undefined;
    }
    return (0,emotion_cache_esm/* default */.Z)({
        key: "mui-style",
        insertionPoint
    });
};

;// CONCATENATED MODULE: ./pages/_document.tsx




class MyDocument extends next_document["default"] {
    render() {
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)(next_document.Html, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)(next_document.Head, {
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("link", {
                            rel: "manifest",
                            href: "/manifest.json"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("link", {
                            rel: "apple-touch-icon",
                            href: "/icon.png"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("meta", {
                            name: "theme-color",
                            content: "#fff"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("body", {
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx(next_document.Main, {}),
                        /*#__PURE__*/ jsx_runtime.jsx(next_document.NextScript, {})
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const _document = (MyDocument);
// `getInitialProps` belongs to `_document` (instead of `_app`),
// it's compatible with static-site generation (SSG).
MyDocument.getInitialProps = async (ctx)=>{
    // Resolution order
    //
    // On the server:
    // 1. app.getInitialProps
    // 2. page.getInitialProps
    // 3. document.getInitialProps
    // 4. app.render
    // 5. page.render
    // 6. document.render
    //
    // On the server with error:
    // 1. document.getInitialProps
    // 2. app.render
    // 3. page.render
    // 4. document.render
    //
    // On the client
    // 1. app.getInitialProps
    // 2. page.getInitialProps
    // 3. app.render
    // 4. page.render
    const originalRenderPage = ctx.renderPage;
    // You can consider sharing the same Emotion cache between all the SSR requests to speed up performance.
    // However, be aware that it can have global side effects.
    const cache = createEmotionCache();
    const { extractCriticalToChunks  } = (0,emotion_server_create_instance_esm/* default */.Z)(cache);
    ctx.renderPage = ()=>originalRenderPage({
            enhanceApp: (App)=>function EnhanceApp(props) {
                    return /*#__PURE__*/ jsx_runtime.jsx(App, {
                        ...props
                    });
                }
        })
    ;
    const initialProps = await next_document["default"].getInitialProps(ctx);
    // This is important. It prevents Emotion to render invalid HTML.
    // See https://github.com/mui/material-ui/issues/26561#issuecomment-855286153
    const emotionStyles = extractCriticalToChunks(initialProps.html);
    const emotionStyleTags = emotionStyles.styles.map((style)=>/*#__PURE__*/ jsx_runtime.jsx("style", {
            "data-emotion": `${style.key} ${style.ids.join(" ")}`,
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML: {
                __html: style.css
            }
        }, style.key)
    );
    return {
        ...initialProps,
        emotionStyleTags
    };
};


/***/ }),

/***/ 3554:
/***/ ((module) => {

module.exports = JSON.parse('{"polyfillFiles":["static/chunks/polyfills-5cd94c89d3acac5f.js"],"devFiles":[],"ampDevFiles":[],"lowPriorityFiles":["static/0NWfxHQYdkUAqVcid0AbU/_buildManifest.js","static/0NWfxHQYdkUAqVcid0AbU/_ssgManifest.js","static/0NWfxHQYdkUAqVcid0AbU/_middlewareManifest.js"],"pages":{"/":["static/chunks/webpack-69bfa6990bb9e155.js","static/chunks/framework-d4c7fbe780b853ea.js","static/chunks/main-15f66ec6222305d1.js","static/css/ef46db3751d8e999.css","static/chunks/pages/index-4c45b77940d9506f.js"],"/_app":["static/chunks/webpack-69bfa6990bb9e155.js","static/chunks/framework-d4c7fbe780b853ea.js","static/chunks/main-15f66ec6222305d1.js","static/css/32d668369076d8cb.css","static/chunks/pages/_app-c4b2c13a9bef782b.js"],"/_error":["static/chunks/webpack-69bfa6990bb9e155.js","static/chunks/framework-d4c7fbe780b853ea.js","static/chunks/main-15f66ec6222305d1.js","static/chunks/pages/_error-5f79c00932c7c9f1.js"],"/about":["static/chunks/webpack-69bfa6990bb9e155.js","static/chunks/framework-d4c7fbe780b853ea.js","static/chunks/main-15f66ec6222305d1.js","static/css/ef46db3751d8e999.css","static/chunks/pages/about-7cdf3428c5c3a536.js"],"/videos/[slug]":["static/chunks/webpack-69bfa6990bb9e155.js","static/chunks/framework-d4c7fbe780b853ea.js","static/chunks/main-15f66ec6222305d1.js","static/chunks/pages/videos/[slug]-280c866d06debdbe.js"]},"ampFirstPages":[]}');

/***/ }),

/***/ 9095:
/***/ ((module) => {

module.exports = {};

/***/ }),

/***/ 240:
/***/ ((module) => {

module.exports = {"Dg":[]};

/***/ })

};
;