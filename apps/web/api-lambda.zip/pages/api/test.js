"use strict";
(() => {
var exports = {};
exports.id = 318;
exports.ids = [318];
exports.modules = {

/***/ 4300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 2361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 3685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 2037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 5477:
/***/ ((module) => {

module.exports = require("punycode");

/***/ }),

/***/ 3477:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 2781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 1576:
/***/ ((module) => {

module.exports = require("string_decoder");

/***/ }),

/***/ 7310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 9796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 5490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ next_serverless_loaderpage_2Fapi_2Ftest_absolutePagePath_private_next_pages_2Fapi_2Ftest_ts_absoluteAppPath_private_next_pages_2F_app_tsx_absoluteAppServerPath_absoluteDocumentPath_private_next_pages_2F_document_tsx_absoluteErrorPath_next_2Fdist_2Fpages_2F_error_absolute404Path_distDir_private_dot_next_buildId_0NWfxHQYdkUAqVcid0AbU_assetPrefix_generateEtags_true_poweredByHeader_true_canonicalBase_basePath_runtimeConfig_previewProps_7B_22previewModeId_22_3A_2253b25bc0b323b60fd3fda570efbafdbd_22_2C_22previewModeSigningKey_22_3A_227893aa8c5d3227e44cf8e1ec2733c3712510844979aaa8367d19e3be712392b1_22_2C_22previewModeEncryptionKey_22_3A_22dd3214264ea6099ab6bbc3d95d1cb4cd51bb6a81a9620c68d6d5ce05eba01771_22_7D_loadedEnvFiles_W10_3D_i18n_reactRoot_true_)
});

// EXTERNAL MODULE: ../../node_modules/next/dist/server/node-polyfill-fetch.js
var node_polyfill_fetch = __webpack_require__(1276);
;// CONCATENATED MODULE: ./deploy/.next/routes-manifest.json
const routes_manifest_namespaceObject = {"Dg":[]};
// EXTERNAL MODULE: ../../node_modules/next/dist/build/webpack/loaders/next-serverless-loader/api-handler.js
var api_handler = __webpack_require__(5021);
;// CONCATENATED MODULE: ../../node_modules/next/dist/build/webpack/loaders/next-serverless-loader/index.js?page=%2Fapi%2Ftest&absolutePagePath=private-next-pages%2Fapi%2Ftest.ts&absoluteAppPath=private-next-pages%2F_app.tsx&absoluteAppServerPath=&absoluteDocumentPath=private-next-pages%2F_document.tsx&absoluteErrorPath=next%2Fdist%2Fpages%2F_error&absolute404Path=&distDir=private-dot-next&buildId=0NWfxHQYdkUAqVcid0AbU&assetPrefix=&generateEtags=true&poweredByHeader=true&canonicalBase=&basePath=&runtimeConfig=&previewProps=%7B%22previewModeId%22%3A%2253b25bc0b323b60fd3fda570efbafdbd%22%2C%22previewModeSigningKey%22%3A%227893aa8c5d3227e44cf8e1ec2733c3712510844979aaa8367d19e3be712392b1%22%2C%22previewModeEncryptionKey%22%3A%22dd3214264ea6099ab6bbc3d95d1cb4cd51bb6a81a9620c68d6d5ce05eba01771%22%7D&loadedEnvFiles=W10%3D&i18n=&reactRoot=true!

        
      const { processEnv } = __webpack_require__(650)
      processEnv([])
    
        
        const runtimeConfig = {}
        ;
        

        

        const combinedRewrites = Array.isArray(routes_manifest_namespaceObject.Dg)
          ? routes_manifest_namespaceObject.Dg
          : []

        if (!Array.isArray(routes_manifest_namespaceObject.Dg)) {
          combinedRewrites.push(...routes_manifest_namespaceObject.Dg.beforeFiles)
          combinedRewrites.push(...routes_manifest_namespaceObject.Dg.afterFiles)
          combinedRewrites.push(...routes_manifest_namespaceObject.Dg.fallback)
        }

        const apiHandler = (0,api_handler/* getApiHandler */.Y)({
          pageModule: __webpack_require__(9671),
          rewrites: combinedRewrites,
          i18n: undefined,
          page: "/api/test",
          basePath: "",
          pageIsDynamic: false,
          encodedPreviewProps: {previewModeId:"53b25bc0b323b60fd3fda570efbafdbd",previewModeSigningKey:"7893aa8c5d3227e44cf8e1ec2733c3712510844979aaa8367d19e3be712392b1",previewModeEncryptionKey:"dd3214264ea6099ab6bbc3d95d1cb4cd51bb6a81a9620c68d6d5ce05eba01771"}
        })
        /* harmony default export */ const next_serverless_loaderpage_2Fapi_2Ftest_absolutePagePath_private_next_pages_2Fapi_2Ftest_ts_absoluteAppPath_private_next_pages_2F_app_tsx_absoluteAppServerPath_absoluteDocumentPath_private_next_pages_2F_document_tsx_absoluteErrorPath_next_2Fdist_2Fpages_2F_error_absolute404Path_distDir_private_dot_next_buildId_0NWfxHQYdkUAqVcid0AbU_assetPrefix_generateEtags_true_poweredByHeader_true_canonicalBase_basePath_runtimeConfig_previewProps_7B_22previewModeId_22_3A_2253b25bc0b323b60fd3fda570efbafdbd_22_2C_22previewModeSigningKey_22_3A_227893aa8c5d3227e44cf8e1ec2733c3712510844979aaa8367d19e3be712392b1_22_2C_22previewModeEncryptionKey_22_3A_22dd3214264ea6099ab6bbc3d95d1cb4cd51bb6a81a9620c68d6d5ce05eba01771_22_7D_loadedEnvFiles_W10_3D_i18n_reactRoot_true_ = (apiHandler);
      

/***/ }),

/***/ 9671:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
function handler(req, res) {
    res.status(200).json({
        name: "John Does"
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [445], () => (__webpack_exec__(5490)));
module.exports = __webpack_exports__;

})();